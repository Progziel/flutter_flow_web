package com.example.document_management_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
