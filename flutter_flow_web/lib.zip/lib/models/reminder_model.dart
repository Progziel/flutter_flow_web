class Reminder {
  final String date;
  final String email;

  Reminder({required this.date, required this.email});
}
