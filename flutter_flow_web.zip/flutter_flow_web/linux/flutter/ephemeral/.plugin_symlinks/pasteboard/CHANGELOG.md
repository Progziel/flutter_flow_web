## 0.2.0

* update docs. [@OutdatedGuy](https://github.com/OutdatedGuy)
* fix js version dependency. [@alexkmbk](https://github.com/alexkmbk)

## 0.1.1

* add `html` to get the html from clipboard. [@alexkmbk](https://github.com/alexkmbk)
* support write image on web.

## 0.1.0

* add web support.
* add `writeText` and `text` support.

## 0.0.3

* Remove `atlimage.h` include for Windows. fix [#75](https://github.com/MixinNetwork/flutter-plugins/issues/75)

## 0.0.2

* add get/write image on iOS.

## 0.0.1

* add Linux,Windows,macOS support.
* support basic functions.
