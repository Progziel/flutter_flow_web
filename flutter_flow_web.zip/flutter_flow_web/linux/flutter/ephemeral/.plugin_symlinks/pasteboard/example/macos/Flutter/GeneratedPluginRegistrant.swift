//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import pasteboard

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  PasteboardPlugin.register(with: registry.registrar(forPlugin: "PasteboardPlugin"))
}
