#import <Flutter/Flutter.h>

@interface PasteboardPlugin : NSObject<FlutterPlugin>
@end
